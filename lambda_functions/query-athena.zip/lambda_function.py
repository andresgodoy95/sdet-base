import boto3
import json
import os
import time

def lambda_handler(event, context):
    athena = boto3.client('athena')

    # Define common Athena settings
    # IMPORTANT: Ensure this output_location is writeable by Athena and your Lambda's role
    # It should ideally come from an environment variable set in CloudFormation
    # output_location = os.environ.get('ATHENA_OUTPUT_LOCATION', 's3://your-athena-results-bucket/path/')
    output_location = f's3://duff-orders-processed/athena_results/' # Using your existing hardcoded value for now
    database = 'db_duff_orders'

    # Extract resource parameter
    resource = None
    if 'queryStringParameters' in event:
        resource = event['queryStringParameters'].get('resource')
    elif 'resource' in event:
        resource = event.get('resource')

    if not resource:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Invalid or missing resource parameter'})
        }

    # Construct query string based on resource requested
    query_type_is_ddl = False # Flag to indicate if it's a DDL query
    if resource == 'client_orders':
        query = """
            SELECT client_id, COUNT(*) as total_orders, SUM(total_price) as total_spent
            FROM db_duff_orders.tbl_duff_orders
            GROUP BY client_id
        """
    elif resource == 'status_summary':
        query = """
            SELECT status, COUNT(*) as count
            FROM db_duff_orders.tbl_duff_orders
            GROUP BY status
        """
    elif resource == 'test':
        query = """
        MSCK REPAIR TABLE db_duff_orders.tbl_duff_orders
        """
        query_type_is_ddl = True # Set the flag for DDL query
    else:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': f'Unknown resource: {resource}'})
        }

    try:
        response = athena.start_query_execution(
            QueryString=query,
            QueryExecutionContext={
                'Database': database
            },
            ResultConfiguration={
                'OutputLocation': output_location
            }
        )

        query_execution_id = response['QueryExecutionId']

        while True:
            result = athena.get_query_execution(QueryExecutionId=query_execution_id)
            status = result['QueryExecution']['Status']['State']
            if status in ['SUCCEEDED', 'FAILED', 'CANCELLED']:
                break
            time.sleep(1)

        if status != 'SUCCEEDED':
            error_message = result['QueryExecution']['Status'].get('StateChangeReason', 'Unknown error')
            return {
                'statusCode': 500,
                'body': json.dumps({'error': f'Athena query failed with status: {status}. Reason: {error_message}'})
            }

        # --- IMPORTANT CHANGE HERE ---
        if query_type_is_ddl:
            # For DDL queries (like MSCK REPAIR TABLE), we don't expect a data result set.
            # Just return a success message.
            return {
                'statusCode': 200,
                'body': json.dumps({'message': f'DDL query "{resource}" executed successfully.', 'query_execution_id': query_execution_id})
            }
        else:
            # For DML queries (like SELECT), process the result set as usual.
            result_response = athena.get_query_results(QueryExecutionId=query_execution_id)

            # Ensure there are rows before trying to access headers
            if not result_response['ResultSet']['Rows']:
                return {
                    'statusCode': 200,
                    'body': json.dumps([]) # Return empty list if no results
                }

            headers = [col['VarCharValue'] for col in result_response['ResultSet']['Rows'][0]['Data']]
            rows = []
            for row in result_response['ResultSet']['Rows'][1:]:
                values = [col.get('VarCharValue', '') for col in row['Data']]
                rows.append(dict(zip(headers, values)))

            return {
                'statusCode': 200,
                'body': json.dumps(rows)
            }

    except Exception as e:
        print(f"An error occurred: {e}") # Log the error for debugging
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }