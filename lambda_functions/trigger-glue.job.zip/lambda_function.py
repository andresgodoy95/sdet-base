import boto3
import os

glue = boto3.client('glue')

def lambda_handler(event, context):
    glue_job_name = "duff_transform_glue_job"
    
    try:
        response = glue.start_job_run(
            JobName=glue_job_name,
            Arguments={
                '--input_bucket': event.get('bucket'),
                '--input_path': f"s3://{event.get('bucket', 'aws-arkho')}/{event.get('key', '')}"
            }
        )
        return {
            "statusCode": 200,
            "job_run_id": response['JobRunId'],
            "message": f"Started Glue job: {glue_job_name}"
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "error": str(e)
        }

