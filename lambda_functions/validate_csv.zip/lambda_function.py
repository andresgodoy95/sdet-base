import csv
import boto3
import os
import logging
import os
from io import StringIO

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    target_bucket = os.environ['PROCESSED_DATA_BUCKET']

    try:
        if 'detail' in event and 'bucket' in event['detail'] and 'object' in event['detail']:
            bucket = event['detail']['bucket']['name']
            key = event['detail']['object']['key']
        elif 'Records' in event and len(event['Records']) > 0:
            bucket = event['Records'][0]['s3']['bucket']['name']
            key = event['Records'][0]['s3']['object']['key']
        else:
            raise ValueError("Bucket or key not found in event")

        # Check file size first
        metadata = s3.head_object(Bucket=bucket, Key=key)
        file_size = metadata['ContentLength']
        logger.info(f"File size: {file_size} bytes")

        if file_size > 100 * 1024 * 1024:
            logger.info("Large file detected. Suggest processing via Glue Job.")
            return {
                'statusCode': 202,
                'file_size': file_size,
                'message': 'Large file detected. Trigger Glue job.',
                'bucket': bucket,
                'key': key,
                'valid': True,
                'is_large': True,
                'target_bucket': target_bucket
            }

        response = s3.get_object(Bucket=bucket, Key=key)
        content = response['Body'].read().decode('utf-8')
        reader = csv.DictReader(StringIO(content))

        required_fields = [
            'client_id', 'client_name', 'order_id', 'product_id',
            'product_description', 'product_price', 'product_ccf',
            'product_volume', 'point_of_sale_channel', 'status'
        ]

        row_num = 1
        for row in reader:
            for field in required_fields:
                if field not in row or row[field].strip() == '':
                    logger.error(f"Row {row_num}: Missing or empty field '{field}'")
                    raise ValueError(f"Invalid data in field '{field}' at row {row_num}")
            row_num += 1

        logger.info("CSV validation passed")
        return {
            'statusCode': 200,
            'message': f"Validation passed for file: {key}",
            'bucket': bucket,
            'key': key,
            'is_large': False,
            'valid': True,
            'target_bucket' : target_bucket 
        }

    except Exception as e:
        logger.exception("Validation failed")
        return {
            'statusCode': 500,
            'error': f"Validation failed: {str(e)}",
            "valid" : 'false'
        }
