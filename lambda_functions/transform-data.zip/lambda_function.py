import csv
import boto3
import io
import pandas as pd
from datetime import datetime

CHUNK_SIZE = 10000  

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    source_bucket = event['bucket']
    source_key = event['key']
    target_bucket = event['target_bucket']

    obj = s3.get_object(Bucket=source_bucket, Key=source_key)
    lines = obj['Body'].read().decode('utf-8').splitlines()
    reader = csv.DictReader(lines)

    date_partition = datetime.utcnow().strftime('%Y-%m-%d')
    chunk_index = 1
    rows = []
    for row in reader:
        row['product_price'] = float(row['product_price'])
        row['product_ccf'] = float(row['product_ccf'])
        row['product_volume'] = float(row['product_volume'])
        row['total_price'] = row['product_price'] * row['product_ccf']
        row['client_id'] = int(row['client_id'])
        row['order_id'] = int(row['order_id'])
        row['product_id'] = int(row['product_id'])
        #row['pa_date'] = date_partition
        rows.append(row)

        if len(rows) >= CHUNK_SIZE:
            write_chunk_to_s3(rows, chunk_index, date_partition, source_key, target_bucket)
            chunk_index += 1
            rows = []

    # Write remaining rows
    if rows:
        write_chunk_to_s3(rows, chunk_index, date_partition, source_key, target_bucket)

    return {
        'statusCode': 200,
        'message': f'Transformed and saved {chunk_index} chunk(s) to S3',
        'chunks_written': chunk_index,
        'target_bucket':target_bucket,
        'resource':'test'
    }

def write_chunk_to_s3(rows, chunk_index, date_partition, source_key, target_bucket):
    df = pd.DataFrame(rows)

    # Explicitly cast columns to correct types
    df['product_price'] = df['product_price'].astype(float)
    df['product_ccf'] = df['product_ccf'].astype(float)
    df['product_volume'] = df['product_volume'].astype(float)
    df['total_price'] = df['total_price'].astype(float)
    df['client_id'] = df['client_id'].astype(int)
    df['order_id'] = df['order_id'].astype(int)
    df['product_id'] = df['product_id'].astype(int)
    df['point_of_sale_channel'] = df['point_of_sale_channel'].astype(str)
    df['status'] = df['status'].astype(str)
    df['client_name'] = df['client_name'].astype(str)
    df['product_description'] = df['product_description'].astype(str)
    #df['pa_date'] = df['pa_date'].astype(str)

    output_buffer = io.BytesIO()
    df.to_parquet(output_buffer, index=False, compression='snappy')

    chunk_key = f"tbl_Duff_prod/pa_date={date_partition}/" + \
                source_key.split('/')[-1].replace('.csv', f'_chunk{chunk_index}.parquet')

    s3 = boto3.client('s3')
    s3.put_object(
        Bucket=target_bucket,
        Key=chunk_key,
        Body=output_buffer.getvalue(),
        ContentType='application/octet-stream'
    )
